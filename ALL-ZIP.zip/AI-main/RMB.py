{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2ca686f5-fb39-4f81-a430-73b6c8fa41b9",
   "metadata": {},
   "outputs": [],
   "source": [
    "dict_gn=dict(\n",
    "    Arad=dict(Zerind=75,Timisoara=118,Sibiu=140),\n",
    "    Zerind=dict(Oradea=71,Arad=75),\n",
    "    Sibiu=dict(Rimnicu=80,Fagaras=99,Arad=140,Oradea=151),\n",
    "    Timisoara=dict(Lugoj=111,Arad=118),\n",
    "    Oradea=dict(Zerind=71,Sibiu=151),\n",
    "    Lugoj=dict(Mehadia=70,Timisoara=111),\n",
    "    Fagaras=dict(Sibiu=99,Bucharest=211),\n",
    "    Rimnicu=dict(Sibiu=80,Pitesti=97,Craiova=146),\n",
    "    Bucharest=dict(Urziceni=85,Giurgiu=90,Pitesti=101,Fagaras=211),\n",
    "    Craiova=dict(Dobreta=120,Pitesti=138,Rimnicu=146),\n",
    "    Dobreta=dict(Mehadia=75,Craiova=120),\n",
    "    Eforie=dict(Hirsova=86),\n",
    "    Hirsova=dict(Eforie=86,Urziceni=98),\n",
    "    Iasi=dict(Neamt=87,Valsui=92),\n",
    "    Pitesti=dict(Rimnicu=97,Bucharest=101,Craiova=138),\n",
    "    Urziceni=dict(Bucharest=85,Hirsova=98,Valsui=142),\n",
    "    Giurgui=dict(Bucharest=90),\n",
    "    Mehadia=dict(Dobreta=75),\n",
    "    Valsui=dict(Iasi=92,Urziceni=142),\n",
    "    Neamt=dict(Iasi=87)\n",
    "    )\n",
    "\n",
    "dict_hn={'Arad':336,'Bucharest':0,'Craiova':160,'Dobreta':242,'Eforie':161,\n",
    "         'Fagaras':176,'Giurgui':77,'Hirsova':151,'Iasi':226,'Lugoj':244,\n",
    "         'Mehadia':241,'Neamt':234,'Oradea':380,'Pitesti':100,'Rimnicu':193,\n",
    "         'Sibiu':253,'Timisoara':329,'Urziceni':80,'Valsui':199,'Zerind':374}\n"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3 (ipykernel)",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.9"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
