# 📁 Download Files

To download a file, right-click on the link and select **"Save link as..."**.

- **[Download P01.ipynb](https://raw.githubusercontent.com/burner-one/AI/main/P01.ipynb)**
- **[Download P02.ipynb](https://raw.githubusercontent.com/burner-one/AI/main/P02.ipynb)**
- **[Download P03.ipynb](https://raw.githubusercontent.com/burner-one/AI/main/P03.ipynb)**
- **[Download P04.ipynb](https://raw.githubusercontent.com/burner-one/AI/main/P04.ipynb)**
- **[Download P05.ipynb](https://raw.githubusercontent.com/burner-one/AI/main/P05.ipynb)**
- **[Download P06.ipynb](https://raw.githubusercontent.com/burner-one/AI/main/P06.ipynb)**
- **[Download P07.ipynb](https://raw.githubusercontent.com/burner-one/AI/main/P07.ipynb)**
- **[Download P08.ipynb](https://raw.githubusercontent.com/burner-one/AI/main/P08.ipynb)**
- **[Download P09.ipynb](https://raw.githubusercontent.com/burner-one/AI/main/P09.ipynb)**
- **[Download diabetes.csv](https://raw.githubusercontent.com/burner-one/AI/main/diabetes.csv)**

---
