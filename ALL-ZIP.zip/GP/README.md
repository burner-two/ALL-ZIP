# 📁 Download Files

To download a file, right-click on the link and select **"Save link as..."**.

- **[Download P01-A.cs](https://raw.githubusercontent.com/burner-one/GP/main/P01-A.cs)**
- **[Download P01-B.cs](https://raw.githubusercontent.com/burner-one/GP/main/P01-B.cs)**
- **[Download P02.py](https://raw.githubusercontent.com/burner-one/GP/main/P02.py)**
- **[Download P03.py](https://raw.githubusercontent.com/burner-one/GP/main/P03.py)**
- **[Download P04.py](https://raw.githubusercontent.com/burner-one/GP/main/P04.py)**
- **[Download P05.py](https://raw.githubusercontent.com/burner-one/GP/main/P05.py)**
- **[Download P06.cs](https://raw.githubusercontent.com/burner-one/GP/main/P06.cs)**
- **[Download P07.cs](https://raw.githubusercontent.com/burner-one/GP/main/P07.cs)**

---
