# 📁 Download Files

To download a file, right-click on the link and select **"Save link as..."**.

- **[Download P01-A.py](https://raw.githubusercontent.com/burner-one/INS/main/P01-A.py)**
- **[Download P01-B.py](https://raw.githubusercontent.com/burner-one/INS/main/P01-B.py)**
- **[Download P02.py](https://raw.githubusercontent.com/burner-one/INS/main/P02.py)**
- **[Download P03.py](https://raw.githubusercontent.com/burner-one/INS/main/P03.py)**
- **[Download P04.py](https://raw.githubusercontent.com/burner-one/INS/main/P04.py)**
- **[Download P05.py](https://raw.githubusercontent.com/burner-one/INS/main/P05.py)**
- **[Download P06.pdf](https://raw.githubusercontent.com/burner-one/INS/main/P06.pdf)**
- **[Download P07.pdf](https://raw.githubusercontent.com/burner-one/INS/main/P07.pdf)**
- **[Download P08.pdf](https://raw.githubusercontent.com/burner-one/INS/main/P08.pdf)**
- **[Download RSA.py](https://raw.githubusercontent.com/burner-one/INS/main/RSA.py)**

---
